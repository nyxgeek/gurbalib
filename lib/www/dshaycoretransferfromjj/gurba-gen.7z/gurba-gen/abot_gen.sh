#!/usr/bin/env bash
python core_ashop.py --start 1 --name abot_1_2 --end 3
python core_ashop.py --start 3 --name abot_3_4 --end 5
python core_ashop.py --start 5 --name abot_5_6 --end 7
python core_ashop.py --start 7 --name abot_7_8 --end 9
python core_ashop.py --start 9 --name abot_9_10 --end 10
python core_ashop.py --start 11 --name abot_11_12 --end 13
python core_ashop.py --start 9 --name abot_9_10 --end 11
python core_ashop.py --start 13 --name abot_13_14 --end 15
python core_ashop.py --start 15 --name abot_15_16 --end 17
python core_ashop.py --start 17 --name abot_17_18 --end 19
python core_ashop.py --start 19 --name abot_19_20 --end 21
