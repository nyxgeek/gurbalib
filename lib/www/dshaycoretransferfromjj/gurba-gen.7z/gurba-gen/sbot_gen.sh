#!/usr/bin/env bash
python core_wshop.py --start 1 --name wbot_1_20 --end 21
