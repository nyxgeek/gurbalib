#!/bin/bash
python room_p.py --area sewer --name 1-f --southwest 1 --east 1 
python room_p.py --area sewer --name 1-g --west 1 --south 1 --east 1 
python room_p.py --area sewer --name 1-h --west 1 --east 1 
python room_p.py --area sewer --name 1-i --west 1 --south 1 --southeast 1 
python room_p.py --area sewer --name 1-j --south 1 --southeast 1 --east 1 
python room_p.py --area sewer --name 1-k --west 1 --east 1 
python room_p.py --area sewer --name 1-l --west 1 --east 1 
python room_p.py --area sewer --name 1-m --west 1 --south 1 
python room_p.py --area sewer --name 1-n --south 1 
python room_p.py --area sewer --name 2-d --south 1 --east 1 
python room_p.py --area sewer --name 2-e --west 1 --northeast 1 
python room_p.py --area sewer --name 2-f --southwest 1 --south 1 --southeast 1 
python room_p.py --area sewer --name 2-g --north 1 --east 1 
python room_p.py --area sewer --name 2-h --west 1 --south 1 
python room_p.py --area sewer --name 2-i --north 1 --south 1 
python room_p.py --area sewer --name 2-j --northwest 1 --north 1 --south 1 
python room_p.py --area sewer --name 2-k --northwest 1 --east 1 --south 1 
python room_p.py --area sewer --name 2-l --west 1 --south 1 
python room_p.py --area sewer --name 2-m --north 1 --south 1 
python room_p.py --area sewer --name 2-n --north 1 --southwest 1 --east 1 
python room_p.py --area sewer --name 2-o --west 1 --east 1 
python room_p.py --area sewer --name 2-p --west 1 --southeast 1 
python room_p.py --area sewer --name 3-c --southwest 1 --south 1 
python room_p.py --area sewer --name 3-d --north 1 --south 1 
python room_p.py --area sewer --name 3-e --northeast 1 --southwest 1 
python room_p.py --area sewer --name 3-f --north 1 --southwest 1 
python room_p.py --area sewer --name 3-g --northwest 1 --southeast 1 
python room_p.py --area sewer --name 3-h --north 1 --east 1 
python room_p.py --area sewer --name 3-i --north 1 --west 1 
python room_p.py --area sewer --name 3-j --north 1 --south 1 
python room_p.py --area sewer --name 3-k --north 1 --east 1 
python room_p.py --area sewer --name 3-l --north 1 --west 1 
python room_p.py --area sewer --name 3-m --north 1 --northeast 1 --south 1 
python room_p.py --area sewer --name 3-n --south 1 --east 1 
python room_p.py --area sewer --name 3-o --west 1 --east 1 
python room_p.py --area sewer --name 3-p --west 1 --south 1 
python room_p.py --area sewer --name 3-q --northwest 1 --south 1 
python room_p.py --area sewer --name 4-b --northeast 1 --south 1 
python room_p.py --area sewer --name 4-c --north 1 --south 1 
python room_p.py --area sewer --name 4-d --north 1 --northeast 1 --southeast 1 --southwest 1 
python room_p.py --area sewer --name 4-e --northeast 1 --up '../../../domains/required/rooms/start' 
python room_p.py --area sewer --name 4-f --east 1 --south 1
python room_p.py --area sewer --name 4-g --west 1 --east 1 
python room_p.py --area sewer --name 4-h --northwest 1 --west 1 --east 1 
python room_p.py --area sewer --name 4-i --west 1 --south 1 --southeast 1 
python room_p.py --area sewer --name 4-j --north 1 --east 1 
python room_p.py --area sewer --name 4-k --west 1 --east 1 
python room_p.py --area sewer --name 4-l --west 1 --north 1 --east 1 --south 1 
python room_p.py --area sewer --name 4-m --north 1 --west 1 
python room_p.py --area sewer --name 4-n --north 1 --southwest 1 
python room_p.py --area sewer --name 4-o --east 1 --south 1 
python room_p.py --area sewer --name 4-p --north 1 --west 1 --south 1 
python room_p.py --area sewer --name 4-q --north 1 --east 1 --south 1 
python room_p.py --area sewer --name 4-r --west 1 --south 1 
python room_p.py --area sewer --name 5-b --north 1 --south 1 
python room_p.py --area sewer --name 5-c --north 1 --northeast 1 
python room_p.py --area sewer --name 5-d --south 1 
python room_p.py --area sewer --name 5-e --northwest 1 --southeast 1 
python room_p.py --area sewer --name 5-f --north 1 --southeast 1 
python room_p.py --area sewer --name 5-g --east 1 
python room_p.py --area sewer --name 5-h --west 1 --south 1 
python room_p.py --area sewer --name 5-i --north 1 --south 1 
python room_p.py --area sewer --name 5-j --northwest 1 --southeast 1 --south 1 
python room_p.py --area sewer --name 5-k --east 1 --southeast 1 
python room_p.py --area sewer --name 5-l --west 1 --north 1 
python room_p.py --area sewer --name 5-m --northeast 1 --south 1 
python room_p.py --area sewer --name 5-n --east 1 --south 1 
python room_p.py --area sewer --name 5-o --north 1 --west 1 
python room_p.py --area sewer --name 5-p --north 1 --south 1 --southwest 1 
python room_p.py --area sewer --name 5-q --north 1 --south 1 
python room_p.py --area sewer --name 5-r --north 1 --south 1 
python room_p.py --area sewer --name 6-a --south 1 
python room_p.py --area sewer --name 6-b --north 1 --southwest 1 
python room_p.py --area sewer --name 6-c --west 1 --east 1 
python room_p.py --area sewer --name 6-d --west 1 --north 1 --east 1 
python room_p.py --area sewer --name 6-e --west 1 --east 1 --south 1 
python room_p.py --area sewer --name 6-f --west 1 --northwest 1 --southeast 1 
python room_p.py --area sewer --name 6-g --northwest 1 --east 1 
python room_p.py --area sewer --name 6-h --west 1 --north 1 --east 1 
python room_p.py --area sewer --name 6-i --west 1 --north 1 
python room_p.py --area sewer --name 6-j --north 1 --southwest 1 --south 1 
python room_p.py --area sewer --name 6-k --northwest 1 --south 1 --southeast 1 
python room_p.py --area sewer --name 6-l --northwest 1 --southeast 1 
python room_p.py --area sewer --name 6-m --north 1 --east 1 
python room_p.py --area sewer --name 6-n --north 1 --west 1 
python room_p.py --area sewer --name 6-o --northeast 1 --south 1 
python room_p.py --area sewer --name 6-p --north 1 
python room_p.py --area sewer --name 6-q --north 1 --southwest 1 
python room_p.py --area sewer --name 6-r --southwest 1 --north 1 --southeast 1 
python room_p.py --area sewer --name 6-s --south 1 
python room_p.py --area sewer --name 7-a --north 1 --northeast 1 --southeast 1 
python room_p.py --area sewer --name 7-b --east 1 --southeast 1 
python room_p.py --area sewer --name 7-c --west 1 --east 1 
python room_p.py --area sewer --name 7-d --west 1 --east 1 
python room_p.py --area sewer --name 7-e --west 1 --north 1 --east 1 
python room_p.py --area sewer --name 7-f --west 1 --southeast 1 
python room_p.py --area sewer --name 7-g --northwest 1 --southeast 1 
python room_p.py --area sewer --name 7-h --east 1 
python room_p.py --area sewer --name 7-i --west 1 --northeast 1 --southeast 1 --south 1 
python room_p.py --area sewer --name 7-j --north 1 --east 1 
python room_p.py --area sewer --name 7-k --west 1 --north 1 
python room_p.py --area sewer --name 7-l --northwest 1 --southwest 1 --south 1 --southeast 1 
python room_p.py --area sewer --name 7-m --northwest 1 --east 1 
python room_p.py --area sewer --name 7-n --west 1 --east 1 
python room_p.py --area sewer --name 7-o --west 1 --north 1 --east 1 
python room_p.py --area sewer --name 7-p --west 1 --northeast 1 
python room_p.py --area sewer --name 7-q --northeast 1 --south 1 
python room_p.py --area sewer --name 7-r --east 1 
python room_p.py --area sewer --name 7-s --north 1 --west 1 --northwest 1 --south 1 
python room_p.py --area sewer --name 8-a --south 1 
python room_p.py --area sewer --name 8-b --southwest 1 --southeast 1 
python room_p.py --area sewer --name 8-c --northwest 1 --south 1 
python room_p.py --area sewer --name 8-d --southwest 1 --south 1 
python room_p.py --area sewer --name 8-e --south 1 --east 1 
python room_p.py --area sewer --name 8-f --west 1 --south 1 
python room_p.py --area sewer --name 8-g --northwest 1 --south 1 
python room_p.py --area sewer --name 8-h --northwest 1 --south 1 --southeast 1 
python room_p.py --area sewer --name 8-i --north 1 --south 1 
python room_p.py --area sewer --name 8-j --northwest 1 --east 1 
python room_p.py --area sewer --name 8-k --west 1 --south 1 --northeast 1 
python room_p.py --area sewer --name 8-l --north 1 --south 1 
python room_p.py --area sewer --name 8-m --northwest 1 --south 1 
python room_p.py --area sewer --name 8-n --east 1 --south 1 
python room_p.py --area sewer --name 8-o --west 1 --east 1 
python room_p.py --area sewer --name 8-p --west 1 --south 1 
python room_p.py --area sewer --name 8-q --southwest 1 --north 1 --north 1 
python room_p.py --area sewer --name 8-r --southwest 1 --east 1 
python room_p.py --area sewer --name 8-s --north 1 --west 1 
python room_p.py --area sewer --name 9-a --north 1 --northeast 1 --southeast 1 --south 1 
python room_p.py --area sewer --name 9-b --east 1 
python room_p.py --area sewer --name 9-c --west 1 --northwest 1 --north 1 --northeast 1 
python room_p.py --area sewer --name 9-d --north 1 --east 1 
python room_p.py --area sewer --name 9-e --west 1 --north 1 
python room_p.py --area sewer --name 9-f --north 1 --east 1 
python room_p.py --area sewer --name 9-g --north 1 --west 1 --east 1 
python room_p.py --area sewer --name 9-h --north 1 --west 1 
python room_p.py --area sewer --name 9-i --north 1 --northwest 1 --southeast 1 
python room_p.py --area sewer --name 9-j --east 1 --down "100-j" 
python room_p.py --area sewer --name 9-k --north 1 --west 1 --southwest 1 
python room_p.py --area sewer --name 9-l --north 1 --south 1 --east 1 
python room_p.py --area sewer --name 9-m --west 1 --north 1 --east 1 
python room_p.py --area sewer --name 9-n --west 1 --north 1 --east 1 
python room_p.py --area sewer --name 9-o --west 1 --east 1 
python room_p.py --area sewer --name 9-p --west 1 --north 1 --northeast 1 --east 1 
python room_p.py --area sewer --name 9-q --west 1 --northeast 1 --east 1 
python room_p.py --area sewer --name 9-r --west 1 --east 1 
python room_p.py --area sewer --name 9-s --west 1 
python room_p.py --area sewer --name 10-a --north 1 --south 1 --southeast 1 
python room_p.py --area sewer --name 10-b --northwest 1 --east 1 
python room_p.py --area sewer --name 10-c --west 1 --east 1 
python room_p.py --area sewer --name 10-c --west 1 --east 1 
python room_p.py --area sewer --name 10-d --west 1 --east 1 
python room_p.py --area sewer --name 10-e --west 1 --east 1 
python room_p.py --area sewer --name 10-f --west 1 --east 1 
python room_p.py --area sewer --name 10-h --west 1 --east 1 
python room_p.py --area sewer --name 10-i --west 1 --south 1 
python room_p.py --area sewer --name 10-j --northwest 1 --northeast 1 --southwest 1 --southeast 1
python room_p.py --area sewer --name 10-k --east 1 --southeast 1 
python room_p.py --area sewer --name 10-l --north 1 --west 1 --south 1 
python room_p.py --area sewer --name 11-a --north 1 --south 1 
python room_p.py --area sewer --name 11-b --northwest 1 --east 1 
python room_p.py --area sewer --name 11-c --west 1 --east 1 
python room_p.py --area sewer --name 11-d --west 1 --east 1 
python room_p.py --area sewer --name 11-e --west 1 --east 1 
python room_p.py --area sewer --name 11-f --west 1 --east 1 
python room_p.py --area sewer --name 11-h --west 1 --east 1 
python room_p.py --area sewer --name 11-i --north 1 --south 1 --west 1 --northeast 1 
python room_p.py --area sewer --name 11-j --south 1 --southeast 1 
python room_p.py --area sewer --name 11-k --northwest 1 --southeast 1 
python room_p.py --area sewer --name 11-l --northwest 1 --north 1 --east 1 
python room_p.py --area sewer --name 11-m --west 1 --east 1 
python room_p.py --area sewer --name 11-n --west 1 --east 1 
python room_p.py --area sewer --name 11-o --west 1 --east 1 
python room_p.py --area sewer --name 11-p --west 1 --southeast 1 
python room_p.py --area sewer --name 11-q --east 1 --south 1 
python room_p.py --area sewer --name 11-r --west 1 --east 1 
python room_p.py --area sewer --name 11-s --west 1 --south 1 
python room_p.py --area sewer --name 12-a --north 1 --south 1 
python room_p.py --area sewer --name 12-b --east 1 --south 1 
python room_p.py --area sewer --name 12-c --west 1 --east 1 
python room_p.py --area sewer --name 12-d --west 1 --east 1 
python room_p.py --area sewer --name 12-e --west 1 --east 1 
python room_p.py --area sewer --name 12-f --west 1 --south 1 --east 1 
python room_p.py --area sewer --name 12-g --west 1 --south 1 --east 1 
python room_p.py --area sewer --name 12-h --west 1 --south 1 
python room_p.py --area sewer --name 12-i --north 1 --south 1 
python room_p.py --area sewer --name 12-j --north 1 --south 1 
python room_p.py --area sewer --name 12-k --northwest 1 --south 1 --east 1 
python room_p.py --area sewer --name 12-l --northwest 1 --south 1 --west 1 
python room_p.py --area sewer --name 12-m --west 1 --east 1 
python room_p.py --area sewer --name 12-n --southwest 1 --west 1 
python room_p.py --area sewer --name 12-o --southwest 1 --south 1 --south 1 
python room_p.py --area sewer --name 12-p --south 1 
python room_p.py --area sewer --name 12-q --north 1 --northwest 1 --southeast 1 
python room_p.py --area sewer --name 12-r --south 1 --down "100-r"
python room_p.py --area sewer --name 12-s --north 1 --south 1 
python room_p.py --area sewer --name 13-a --north 1 --south 1 
python room_p.py --area sewer --name 13-b --north 1 --south 1 --east 1 
python room_p.py --area sewer --name 13-c --west 1 --east 1 
python room_p.py --area sewer --name 13-d --south 1 
python room_p.py --area sewer --name 13-e --south 1 --east 1 
python room_p.py --area sewer --name 13-f --north 1 --west 1 --south 1 
python room_p.py --area sewer --name 13-g --north 1 --south 1 
python room_p.py --area sewer --name 13-h --north 1 --south 1 --east 1 
python room_p.py --area sewer --name 13-i --north 1 --south 1 --west 1 
python room_p.py --area sewer --name 13-j --north 1 --south 1 
python room_p.py --area sewer --name 13-k --north 1 --south 1 
python room_p.py --area sewer --name 13-l --north 1 --south 1 
python room_p.py --area sewer --name 13-m --northeast 1 --south 1 --down "100-m" 
python room_p.py --area sewer --name 13-n --northeast 1 --south 1 
python room_p.py --area sewer --name 13-o --north 1 --east 1 
python room_p.py --area sewer --name 13-p --north 1 --west 1 --east 1 
python room_p.py --area sewer --name 13-q --west 1 --east 1 
python room_p.py --area sewer --name 13-r --west 1 --northwest 1 --north 1 
python room_p.py --area sewer --name 13-s --north 1 --southwest 1 
python room_p.py --area sewer --name 14-a --north 1 --southeast 1 
python room_p.py --area sewer --name 14-b --north 1 --southeast 1 
python room_p.py --area sewer --name 14-c --southeast 1 --east 1 
python room_p.py --area sewer --name 14-d --west 1 --northwest 1 --north 1 
python room_p.py --area sewer --name 14-e --north 1 --south 1 
python room_p.py --area sewer --name 14-f --north 1 --south 1 
python room_p.py --area sewer --name 14-g --north 1 --south 1 
python room_p.py --area sewer --name 14-h --north 1 --south 1 
python room_p.py --area sewer --name 14-i --north 1 --south 1 
python room_p.py --area sewer --name 14-j --north 1 --southeast 1 
python room_p.py --area sewer --name 14-k --north 1 --southeast 1 
python room_p.py --area sewer --name 14-l --north 1 --east 1 
python room_p.py --area sewer --name 14-m --west 1 --north 1 --east 1 
python room_p.py --area sewer --name 14-n --west 1 --north 1 --east 1 
python room_p.py --area sewer --name 14-o --west 1 --east 1 
python room_p.py --area sewer --name 14-p --west 1 --east 1 
python room_p.py --area sewer --name 14-q --west 1 --southwest 1 --south 1 --east 1 
python room_p.py --area sewer --name 14-r --west 1 --northeast 1 --east 1 
python room_p.py --area sewer --name 14-s --west 1 --southwest 1 
python room_p.py --area sewer --name 15-b --northwest 1 --south 1 
python room_p.py --area sewer --name 15-c --northwest 1 --south 1 
python room_p.py --area sewer --name 15-d --northwest 1 --south 1 
python room_p.py --area sewer --name 15-e --north 1 --south 1 --east 1 
python room_p.py --area sewer --name 15-f --north 1 --west 1 
python room_p.py --area sewer --name 15-g --north 1 --south 1 
python room_p.py --area sewer --name 15-h --north 1 --south 1 
python room_p.py --area sewer --name 15-i --north 1 --south 1 
python room_p.py --area sewer --name 15-j --south 1 --southeast 1 
python room_p.py --area sewer --name 15-k --northwest 1 --east 1 --southeast 1 
python room_p.py --area sewer --name 15-l --west 1 --northwest 1 --east 1 
python room_p.py --area sewer --name 15-m --west 1 --east 1 
python room_p.py --area sewer --name 15-n --west 1 --east 1 
python room_p.py --area sewer --name 15-o --west 1 --south 1 
python room_p.py --area sewer --name 15-p --northeast 1 --south 1 
python room_p.py --area sewer --name 15-q --north 1 --down "100-q" 
python room_p.py --area sewer --name 15-r --northeast 1 --south 1 
python room_p.py --area sewer --name 16-b --north 1 --southeast 1 
python room_p.py --area sewer --name 16-c --north 1 --southeast 1 
python room_p.py --area sewer --name 16-d --north 1 --east 1 
python room_p.py --area sewer --name 16-e --west 1 --north 1 --east 1 
python room_p.py --area sewer --name 16-f --west 1 --east 1 
python room_p.py --area sewer --name 16-g --west 1 --north 1 
python room_p.py --area sewer --name 16-h --north 1 --south 1 
python room_p.py --area sewer --name 16-i --north 1 --south 1 
python room_p.py --area sewer --name 16-j --north 1 --south 1 
python room_p.py --area sewer --name 16-k --northwest 1 --southeast 1 
python room_p.py --area sewer --name 16-l --northwest 1 --east 1 
python room_p.py --area sewer --name 16-m --west 1 --southeast 1 --east 1 
python room_p.py --area sewer --name 16-n --west 1 --east 1 
python room_p.py --area sewer --name 16-o --north 1 --west 1 
python room_p.py --area sewer --name 16-p --north 1 --south 1 
python room_p.py --area sewer --name 16-q --east 1 --south 1 
python room_p.py --area sewer --name 16-r --north 1 --west 1 
python room_p.py --area sewer --name 17-c --northwest 1 --southeast 1 
python room_p.py --area sewer --name 17-d --northwest 1 --east 1 
python room_p.py --area sewer --name 17-e --west 1 --east 1 
python room_p.py --area sewer --name 17-f --west 1 --east 1 
python room_p.py --area sewer --name 17-g --west 1 --south 1 
python room_p.py --area sewer --name 17-h --north 1 --south 1 
python room_p.py --area sewer --name 17-i --north 1 --south 1 
python room_p.py --area sewer --name 17-j --north 1 --south 1 --east 1 
python room_p.py --area sewer --name 17-k --west 1 --south 1 --southeast 1 
python room_p.py --area sewer --name 17-l --northwest 1 --east 1 
python room_p.py --area sewer --name 17-m --west 1 --south 1 
python room_p.py --area sewer --name 17-n --northwest 1 --east 1 --south 1 
python room_p.py --area sewer --name 17-o --west 1 --south 1 
python room_p.py --area sewer --name 17-p --southwest 1 --north 1 --east 1 
python room_p.py --area sewer --name 17-q --west 1 --north 1 
python room_p.py --area sewer --name 18-d --northwest 1 --east 1 
python room_p.py --area sewer --name 18-e --west 1 --east 1 
python room_p.py --area sewer --name 18-f --west 1 --southeast 1 
python room_p.py --area sewer --name 18-g --north 1 --east 1 
python room_p.py --area sewer --name 18-h --west 1 --north 1 
python room_p.py --area sewer --name 18-i --southwest 1 --north 1 
python room_p.py --area sewer --name 18-j --south 1 --north 1 
python room_p.py --area sewer --name 18-k --north 1 --east 1 
python room_p.py --area sewer --name 18-l --northwest 1 --west 1 --southeast 1 
python room_p.py --area sewer --name 18-m --north 1 --east 1 
python room_p.py --area sewer --name 18-n --west 1 --north 1 --east 1 
python room_p.py --area sewer --name 18-o --west 1 --north 1 --southwest 1 --northeast 1 --east 1 
python room_p.py --area sewer --name 18-p --west 1 
python room_p.py --area sewer --name 19-f --east 1 
python room_p.py --area sewer --name 19-g --west 1 --northwest 1 --east 1 
python room_p.py --area sewer --name 19-h --west 1 --northeast 1 --east 1 
python room_p.py --area sewer --name 19-i --west 1 --east 1 
python room_p.py --area sewer --name 19-k --west 1 --east 1 
python room_p.py --area sewer --name 19-l --west 1 --east 1 
python room_p.py --area sewer --name 19-m --west 1 --northwest 1 --east 1 
python room_p.py --area sewer --name 19-n --west 1 --northeast 1 
python room_p.py --area sewer --name 100-j --up 9-j
python room_p.py --area sewer --name 100-r --up 12-r 
python room_p.py --area sewer --name 100-m --up 13-m 
python room_p.py --area sewer --name 100-q --up 15-q 
